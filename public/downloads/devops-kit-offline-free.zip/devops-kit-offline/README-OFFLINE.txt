DevOps Kit - Offline Starter (free)
====================================
1. Unzip this folder anywhere (Desktop is fine).
2. Double-click  index.html  (opens in Chrome, Edge, Firefox or Safari).
3. Pick a card and start. Everything works without internet.

What is inside: free lessons, practice terminals, and the Linux Server Lab free demo (22 missions).
Your progress is saved in this browser on this computer.
Language picker (top of each page): English, Hindi, Telugu, Tamil.

The full course: https://promptstudioai.in
Support: support@promptstudioai.in
