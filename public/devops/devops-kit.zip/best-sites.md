# Best Sites — What To Pick, And Why (Draft)

## A warning first
Prices change often. Prices below come from earlier research done in
October 2026 and are NOT freshly verified here — check the site
itself before paying anything. Free options are listed first on
purpose: start free, pay only when you know what you need.

## The map (free, start here)
- **roadmap.sh/devops** — Pick this first to see the whole path in
  one picture: Linux, Git, Docker, Kubernetes, Terraform, CI/CD,
  monitoring, in order.
  Why: it answers "what do I learn next?" in one page. It teaches
  little by itself, so use it as a map, not a course.

## Free learning, topic by topic
- **freeCodeCamp** — Pick this for free written guides and video
  series on Linux, Docker, and Kubernetes basics.
  Why: free, beginner-friendly, and easy to follow in small pieces.
- **TechWorld with Nana (YouTube)** — Pick this when a written
  guide is not clicking and you want a concept explained slowly
  with diagrams.
  Why: clear, visual explanations of Docker, Kubernetes, and CI/CD
  ideas.
- **Learn Git Branching (browser game)** — Pick this to practise
  Git branching in your browser, with no setup.
  Why: you learn by doing, and mistakes cost nothing here.
- **Free GitHub DevOps roadmap** (chanupen/devops-roadmap: 34
  hands-on modules from Linux to Kubernetes) — Pick this when you
  want guided labs on one machine.
  Why: it is free, practical, and its labs run on a single Linux
  machine, so no cloud bill. If a link fails, search for the
  repository name.
- **Docker's official getting-started guide** — Pick this when you
  want the toolmaker's own first steps for Docker, in order.
  Why: free, and it matches the current version.
- **Kubernetes official tutorials** — Pick these when you reach
  Kubernetes and want short guided exercises from the people who
  make Kubernetes.
  Why: free, and they match the current version.
- **Pro Git book (free online)** — Pick this when Git clicks and
  you want the full story, including branching and conflicts.
  Why: free, written clearly, and it is the standard Git book.
- **Killercoda browser scenarios** — Pick this when your own
  machine is busy and you want a free terminal in the browser for
  Linux, Docker, Kubernetes, or Git practice.
  Why: no setup at all; free scenarios exist, though the free
  offering can change — check the site.

## Paid, when you are ready
- **KodeKloud** — Pick this when you want hands-on labs inside the
  browser, especially for Kubernetes.
  Why: you practise on real lab machines instead of only watching
  videos. Earlier research priced it around ₹1,300/month — unverified
  here, check before paying.
- **Udemy** — Pick this for one cheap course on one topic (for
  example, Docker for beginners), during a sale.
  Why: you pay once per course and keep it. Earlier research found
  courses around ₹449–₹3,499 — unverified here, and quality varies
  by instructor, so check ratings and last-updated date first.
- **HashiCorp's own Terraform tutorials** — Pick these when you
  reach Terraform, before any paid Terraform course.
  Why: free, written by the people who make Terraform, and they
  match the current version.

## What NOT to buy first
- A big bootcamp (tens of thousands of rupees) before you have
  finished the free map, the zero-cost lab, and one portfolio
  project. If you cannot finish free work, an expensive course will
  not finish it for you.
- Any course that promises a job or a salary. No course can promise
  that, whatever its page says.

## The simple rule
Map first (roadmap.sh), free guides second, one paid course only
for the topic you are stuck on, and your own projects all the way
through. The projects are the part employers can actually see.
