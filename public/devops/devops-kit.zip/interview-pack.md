# Interview Pack — Real Questions, What They Really Test (Draft)

## How to use this
Read the question, answer out loud in your own words, then read the
"really testing" line. Interviewers care less about perfect wording
and more about whether you understand the idea and have done it.
If you have not done it, say what you did instead — do not pretend.

## Linux and Git
1. What does `chmod 755` do?
   Really testing: do you understand file permissions (who can read,
   write, and run a file)?
2. A program is using too much CPU. How do you find which one?
   Really testing: can you use basic tools (`top`, `ps`) to look at
   a live machine?
3. What is the difference between `git pull` and `git fetch`?
   Really testing: do you know that fetch only downloads, while pull
   downloads and merges?
4. Your branch has a conflict. What do you do?
   Really testing: can you stay calm, read the conflict markers, pick
   the right lines, and finish the merge?

## Docker
5. What is a container, and how is it different from a virtual
   machine?
   Really testing: do you know a container shares the host's system
   while a virtual machine runs a whole second system?
6. What is a Dockerfile?
   Really testing: can you describe a build recipe in plain words?
7. Your container starts and stops at once. Where do you look first?
   Really testing: do you check `docker logs` before guessing?
8. Why map ports with `-p 8080:80`?
   Really testing: do you understand that the container's port and
   your machine's port are two different doors?

## Kubernetes
9. What is a pod?
   Really testing: do you know it is the smallest thing Kubernetes
   runs, usually holding one container?
10. What does a deployment do?
    Really testing: do you know it keeps a chosen number of copies
    of your app running and replaces failed ones?
11. Your pod keeps crashing and restarting. How do you debug it?
    Really testing: can you read pod logs and describe the failure,
    instead of just restarting it again?
12. What is a service in Kubernetes?
    Really testing: do you know it gives a stable address to pods
    that come and go?

## Terraform and CI/CD
13. What is "infrastructure as code"?
    Really testing: can you explain writing down wanted
    infrastructure in files instead of clicking around by hand?
14. What is Terraform state, and why does it matter?
    Really testing: do you know Terraform keeps a record of what it
    created, so it knows what to change next time?
15. What happens in a CI/CD pipeline when you push code?
    Really testing: can you walk through test, build, and deploy in
    order?
16. A pipeline fails. What is your first step?
    Really testing: do you read the failed step's log before
    changing anything?

## Monitoring and general
17. How do you know if an app is healthy?
    Really testing: do you check more than "it opened once" — uptime,
    speed, errors, and resource use?
18. What is the difference between a metric and a log?
    Really testing: do you know a metric is a number over time (like
    CPU use) and a log is a written record of events?
19. Describe a project you built and one problem you fixed in it.
    Really testing: can you explain your own work clearly — this is
    usually the question that decides the interview.
20. You do not know the answer to a question. What do you say?
    Really testing: honesty and method — "I don't know, but here is
    how I would find out" beats a confident guess.
21. What is the difference between an image and a container?
    Really testing: do you know an image is the saved recipe and a
    container is the image running?
22. Your YAML file fails with a strange error. What do you check
    first?
    Really testing: do you check the spaces — YAML breaks on tabs
    and wrong indentation?
23. You wrote a script but running it says "permission denied".
    What do you do?
    Really testing: do you know the file needs `chmod +x` before
    it can run?

## No promises
Knowing these answers does not guarantee a job. Interviews also test
communication, teamwork, and the employer's own needs. Use this pack
to practise, not as a promise of any result.
