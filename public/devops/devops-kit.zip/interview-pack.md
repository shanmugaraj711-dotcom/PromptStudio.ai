# Interview Pack — Real Questions, What They Really Test (Draft)

## How to use this
Read the question, answer out loud in your own words, then read the
sample answer and the "really testing" line. Interviewers care less
about perfect wording and more about whether you understand the idea
and have done it. If you have not done it, say what you did instead
— do not pretend.

## Linux and Git
1. What does `chmod 755` do?
   Sample answer: owner gets read, write, execute (rwx); group and
   others get read and execute (r-x). Written out: rwxr-xr-x.
   7 = 4+2+1 (read+write+execute), 5 = 4+1 (read+execute).
   Really testing: do you understand file permissions (who can read,
   write, and run a file)?
2. A program is using too much CPU. How do you find which one?
   Sample answer: `top` for a live view (sort by CPU), or
   `ps aux` for a snapshot. Note the program's name and PID, and
   check what it is before you stop anything.
   Really testing: can you use basic tools (`top`, `ps`) to look at
   a live machine?
3. What is the difference between `git pull` and `git fetch`?
   Sample answer: fetch only downloads the latest changes — it does
   not touch your files. Pull fetches and then integrates them,
   usually by merge (or by rebase, if that is how it is set up).
   Really testing: do you know that fetch only downloads, while pull
   downloads and integrates?
4. Your branch has a conflict. What do you do?
   Sample answer: open the file, read the conflict markers
   (`<<<<<<<`, `=======`, `>>>>>>>`), pick the correct lines,
   delete the markers, stage the file, and commit to finish the
   merge.
   Really testing: can you stay calm, read the conflict markers, pick
   the right lines, and finish the merge?

## Docker
5. What is a container, and how is it different from a virtual
   machine?
   Sample answer: a container shares the host machine's system
   (kernel) and runs just your app and its needs, so it is light.
   A virtual machine runs a whole second system, kernel included,
   so it is heavier.
   Really testing: do you know a container shares the host's system
   while a virtual machine runs a whole second system?
6. What is a Dockerfile?
   Sample answer: a short text recipe — start from a base image,
   copy files in, install what is needed, say what to run. `docker
   build` turns it into an image.
   Really testing: can you describe a build recipe in plain words?
7. Your container starts and stops at once. Where do you look first?
   Sample answer: a container lives only as long as its main program
   runs. Check `docker ps -a` to see it exited, then `docker logs`
   for the error — the program probably crashed or had nothing to do.
   Really testing: do you check `docker logs` before guessing?
8. Why map ports with `-p 8080:80`?
   Sample answer: 8080 is your machine's door, 80 is the container's
   door. Without the mapping, your browser cannot reach the app
   inside the container.
   Really testing: do you understand that the container's port and
   your machine's port are two different doors?

## Kubernetes
9. What is a pod?
   Sample answer: the smallest thing Kubernetes runs, usually holding
   one container, with its own shared network address and storage.
   Really testing: do you know it is the smallest thing Kubernetes
   runs, usually holding one container?
10. What does a deployment do?
    Sample answer: it keeps the number of copies you set running,
    replaces failed ones, and handles updates for you.
    Really testing: do you know it keeps a chosen number of copies
    of your app running and replaces failed ones?
11. Your pod keeps crashing and restarting. How do you debug it?
    Sample answer: `kubectl get pods`, then `kubectl describe pod`
    (read the Events at the bottom), then `kubectl logs`, and
    `kubectl logs --previous` for the crashed run's output. Fix the
    cause — bad image, bad setting — not just restart it again.
    Really testing: can you read pod logs and describe the failure,
    instead of just restarting it again?
12. What is a service in Kubernetes?
    Sample answer: a stable address inside the cluster for pods that
    come and go — it matches pods by their labels. In this kit's
    local lab, your browser reaches it through `kubectl
    port-forward`; that does not expose it publicly.
    Really testing: do you know it gives a stable address to pods
    that come and go?

## Terraform and CI/CD
13. What is "infrastructure as code"?
    Sample answer: writing down the infrastructure you want in
    files, and letting a tool create it — repeatable, reviewable,
    and the same every time, instead of clicking around by hand.
    Really testing: can you explain writing down wanted
    infrastructure in files instead of clicking around by hand?
14. What is Terraform state, and why does it matter?
    Sample answer: state maps each thing in your files to the real
    thing Terraform created, and stores what it needs to plan the
    next change. It can hold private values, so it must never go
    into a public repository.
    Really testing: do you know Terraform keeps a map from your
    files to the real infrastructure, not just a list of what it
    made?
15. What happens in a CI/CD pipeline when you push code?
    Sample answer: the push starts the workflow — it runs the test
    step, then the build step. Delivery means a change is tested and
    ready to release; deployment means it is released automatically.
    This kit's pipeline tests and builds; it does not deploy.
    Really testing: can you walk through test and build in order,
    and say what delivery and deployment each mean?
16. A pipeline fails. What is your first step?
    Sample answer: open the failed run, read the failed step's log,
    find the first error line, and fix that one thing first.
    Really testing: do you read the failed step's log before
    changing anything?

## Monitoring and general
17. How do you know if an app is healthy?
    Sample answer: check more than "it opened once" — is it up, is
    it fast enough, are errors low, are memory and CPU sane?
    Really testing: do you check more than "it opened once" — uptime,
    speed, errors, and resource use?
18. What is the difference between a metric and a log?
    Sample answer: a metric is a number over time (like CPU use); a
    log is a written record of events ("at this time, this
    happened").
    Really testing: do you know a metric is a number over time (like
    CPU use) and a log is a written record of events?
19. Describe a project you built and one problem you fixed in it.
    Sample answer (shape, in your own words): "I built [project].
    One problem was [symptom]. I found it by [what you checked].
    I fixed it by [change], and proved it by [how you checked]."
    Really testing: can you explain your own work clearly — this is
    usually the question that decides the interview.
20. You do not know the answer to a question. What do you say?
    Sample answer: "I don't know, but here is how I would find
    out" — then name the steps: check the docs, reproduce it
    small, test one idea at a time.
    Really testing: honesty and method — "I don't know, but here is
    how I would find out" beats a confident guess.
21. What is the difference between an image and a container?
    Sample answer: the Dockerfile is the recipe, the image is the
    built copy, and a container is the image running. One image
    can run as many containers.
    Really testing: do you know the Dockerfile is the recipe, the
    image is the built copy, and a container is the image running?
22. Your YAML file fails with a strange error. What do you check
    first?
    Sample answer: the spaces — YAML breaks on tabs and wrong
    indentation. Check the line the error names first.
    Really testing: do you check the spaces — YAML breaks on tabs
    and wrong indentation?
23. You wrote a script but running it says "permission denied".
    What do you do?
    Sample answer: first check the execute bit — `chmod +x` if it
    is missing. If that does not fix it, check the file's owner,
    the folder's permissions, and whether the disk allows running
    files. If it names a missing interpreter, check the script's
    first line and whether that program is installed.
    Really testing: do you know `chmod +x` is only the first check,
    not the only possible cause?

## No promises
Knowing these answers does not guarantee a job. Interviews also test
communication, teamwork, and the employer's own needs. Use this pack
to practise, not as a promise of any result.
