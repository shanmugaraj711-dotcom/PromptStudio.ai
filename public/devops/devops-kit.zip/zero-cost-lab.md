# Zero-Cost Lab — One Machine, No Cloud Bill (Draft)

## What you need
- A computer with internet.
- Linux. If you use Windows, install WSL2 with Ubuntu first (Windows
  Subsystem for Linux — a way to run Linux inside Windows). If you
  use a Mac, the Docker steps below need Docker Desktop instead.
- No cloud account. No card. Nothing here costs money.

## Open a terminal first
- Linux: press Ctrl+Alt+T, or find Terminal in your apps.
- Mac: open the Terminal app.
- Windows: after WSL2 and Ubuntu are installed, open Ubuntu from
  the Start menu — that window is your Linux terminal.

## A note on the commands
The commands below are well-known, standard Linux commands. They are
written for Ubuntu/Debian Linux. On other systems, package names and
setup steps can differ — that part is unverified here, so check your
system's own Docker docs if a step fails.
Three words you will see in commands: `sudo` means "run this as the
machine's administrator" (it may ask for your password);
`apt` is Ubuntu's app installer; `~` means your home folder.

## How to make a file (you will need this)
Projects and labs ask you to make files like `index.html`,
`Dockerfile`, and `.yml` files. Two easy ways:
1. With a text editor: type `nano index.html`, write your text,
   press Ctrl+O then Enter to save, Ctrl+X to leave.
2. Straight from the terminal (good for short files):

```
cat > index.html << 'EOF'
<h1>My site</h1>
<p>Learning DevOps, one project at a time.</p>
EOF
```

`cat >` writes what follows into the file until the `EOF` line.
One YAML warning: YAML files use spaces for structure — never use
the Tab key in a `.yml` or `.yaml` file. If a YAML file fails with
a strange error, check the spaces first.

## Step 1 — Check what you already have
Open a terminal and run:

```
git --version
docker --version
```

If both print a version number, skip to Step 3. If either says
"command not found", go to Step 2.

## Step 2 — Install Git and Docker (Ubuntu/Debian)
```
sudo apt update
sudo apt install -y git docker.io
sudo systemctl enable --start docker
sudo usermod -aG docker $USER
```

Then close the terminal, open it again, and run:

```
docker --version
```

The `usermod` step lets you run Docker without typing `sudo` each
time. It only takes effect after you open a fresh terminal (or log
out and back in).

## Step 3 — Prove Docker works
```
docker run hello-world
```

You should see a message saying Docker is working. This downloads a
tiny test image and runs it once. If it fails, read the error: the
most common cause is that Docker is not running — run
`sudo systemctl start docker` and try again.
If the error says "permission denied", your terminal session has
not picked up the Docker group yet — run `newgrp docker`, or close
the terminal and open it again, then retry.

## Step 4 — Run your first real container
```
docker run -d -p 8080:80 --name my-site nginx
```

What this means:
- `-d` — run in the background.
- `-p 8080:80` — connect port 8080 on your machine to port 80
  inside the container. A port is just a numbered door for network
  traffic.
- `--name my-site` — give the container a name you can use later.
- `nginx` — a small, well-known web server program.

Now open your browser and go to `http://localhost:8080`.
You should see the nginx welcome page. `localhost` means "this
machine".

## Step 5 — Look at it and stop it
```
docker ps
docker stop my-site
docker ps
```

`docker ps` lists running containers. After `docker stop`, the
second `docker ps` should show nothing — your container is stopped.
To start it again later: `docker start my-site`. To remove it fully:
`docker rm my-site`.

## Step 6 — Make a folder for your work
```
mkdir -p ~/devops-practice
cd ~/devops-practice
```

All later labs and projects in this kit live in this folder.

## Step 7 — Put your work on GitHub (first time only)
The projects ask you to "push to GitHub". The first time, do this
once:
1. Make a free account on github.com, then make a new repository
   (a folder on GitHub that holds your project). GitHub will show
   you the repository's address — copy it.
2. In your terminal, from inside your project folder, run:

```
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin <your repository address>
git push -u origin main
```

What this means: `git init` starts tracking the folder,
`git add .` stages everything, `commit` saves it,
`branch -M main` names your main line of work "main",
`remote add origin` connects your folder to GitHub,
and `push` sends it there. After this first push, later pushes
are just `git add .`, `git commit -m "message"`, `git push`.
Replace `<your repository address>` with the address GitHub
showed you — do not type the brackets.

## Step 8 — Your first script
A script is a text file full of commands. Make one that checks
your Docker containers:

```
cat > health-check.sh << 'EOF'
#!/bin/bash
echo "Running containers:"
docker ps --format "{{.Names}} is {{.Status}}"
EOF
chmod +x health-check.sh
./health-check.sh
```

What this means: the first line says "run this with Bash";
`chmod +x` makes the file runnable; `./` means "run the file in
this folder". If you forget `chmod +x`, you get "permission
denied" — that error almost always means "this file is not
marked runnable yet".

## If something goes wrong
1. Read the error message fully before searching for help.
2. `docker ps -a` shows stopped containers too — useful when a
   container died.
3. `docker logs my-site` shows what a container printed before it
   stopped. Logs are the first place to look, always.

## What costs money (so you can avoid it)
Cloud servers, hosted Kubernetes, and paid course platforms cost
money. Nothing in this lab needs them. If a later step in this kit
mentions a cloud service, it will say so clearly and give a local
alternative first.
