# Kubernetes Lab — Your App on a Small Local Cluster (Draft)

## What this lab is
You will run your Project 1 website on a small Kubernetes cluster
that lives on your own machine. No cloud account, no bill. You will
also break it on purpose and fix it, the same way you did in the
break-and-fix labs.

## What you need first
- Docker running (from zero-cost-lab.md).
- Your Project 1 image built: `my-site:1.0` (from
  portfolio-projects.md). If you deleted it, move into the
  Project 1 folder and build it again first:

```
cd ~/devops-practice/my-site
docker build -t my-site:1.0 .
```

## Why kind
This kit uses kind (short for "Kubernetes in Docker"). It runs a
whole cluster as containers on your machine, so it needs only
Docker, which you already have. The other common choice is
minikube, but this kit uses kind only, so every command below
matches.

## Step 1 — Install kubectl and kind (Linux)
`kubectl` is the command tool for talking to a cluster. `kind`
is the tool that creates the cluster.

```
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/kubectl
```

```
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.23.0/kind-linux-amd64
chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind
```

Check both installed:

```
kind version
kubectl version --client
```

Both should print a version number. Note: the kind version number
changes over time — if that download link fails, take the newest
link from kind's install page. Mac and Windows install steps
differ (Homebrew or choco) and are unverified in this kit.

## Step 2 — Start the cluster
```
kind create cluster --name devops-practice
```

The first run downloads the cluster's node image, so it takes a
few minutes. Then check it:

```
kubectl get nodes
```

You should see one node with STATUS Ready. If you see nothing,
make sure Docker is running and try again.

## Step 3 — Load your image into the cluster
A kind cluster cannot see images sitting in your local Docker by
itself. This is the step most beginners forget. Copy your image
in:

```
kind load docker-image my-site:1.0 --name devops-practice
```

Without this step, the cluster would try to download your image
from the internet and fail, because your image only exists on
your machine.

## Step 4 — Run your app with a Deployment
A Deployment (a way to say "keep copies of my app running") is
described in a file. Make a file called `deployment.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-site
spec:
  replicas: 1
  selector:
    matchLabels:
      app: my-site
  template:
    metadata:
      labels:
        app: my-site
    spec:
      containers:
        - name: web
          image: my-site:1.0
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 80
```

`imagePullPolicy: IfNotPresent` tells Kubernetes to use the image
you loaded in Step 3 instead of trying to download it again.
`replicas: 1` means one copy of your app.

Apply it and look at your pods (a pod is the smallest thing
Kubernetes runs, usually one container):

```
kubectl apply -f deployment.yaml
kubectl get pods
```

You should see one pod named like `my-site-xxxx`, with READY
1/1 and STATUS Running. Pod names differ every time — copy the
real name from the output for the commands below.

Open your app in the browser:

```
kubectl port-forward deployment/my-site 8080:80
```

This connects port 8080 on your machine to your app. Open
`http://localhost:8080` — you should see your Project 1 site.
Keep this terminal open while you look; stopping it with Ctrl+C
only stops the forwarding, not your app.

Expose it with a Service: a Service gives your app a stable
address inside the cluster, even when pods come and go. Make a
file called `service.yaml`:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-site
spec:
  selector:
    app: my-site
  ports:
    - port: 80
```

`selector` connects the Service to pods labelled `app: my-site`
— the same label your Deployment gives its pods. Apply and check:

```
kubectl apply -f service.yaml
kubectl get services
```

You should see `my-site` with a CLUSTER-IP. Open it through the
Service instead of the Deployment:

```
kubectl port-forward service/my-site 8080:80
```

Open `http://localhost:8080` again — same site, now reached
through the Service. This is the address other things inside the
cluster would use.

Read about your pod:

```
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

`describe` shows details and recent events. `logs` shows what
your app printed. When something breaks, these two commands are
where you look first.

## Step 5 — Break it, then fix it
Break it: change the image in `deployment.yaml` to a tag that
does not exist, for example `my-site:badtag`, and apply it again:

```
kubectl apply -f deployment.yaml
kubectl get pods
```

Your pod will not reach Running. Its STATUS will show something
like ImagePullBackOff or ErrImagePull, and its restarts may climb.

Find it:

```
kubectl describe pod <pod-name>
```

Read the Events at the bottom. They will say the image could not
be pulled or was not found. The lesson: the Deployment file is
wrong, not the pod. A pod only does what its Deployment says.

Fix it: change the image back to `my-site:1.0` in
`deployment.yaml`, apply it again, and check:

```
kubectl apply -f deployment.yaml
kubectl get pods
```

A new pod starts and reaches Running. Deleting the broken pod
alone would NOT have fixed it — the Deployment would simply
have made the same broken pod again. Fix the Deployment, and
the pod follows.

Try self-healing once: on the healthy pod, run
`kubectl delete pod <pod-name>`, then `kubectl get pods` again.
The Deployment makes a healthy replacement by itself. That is
why Deployments exist: they keep your chosen number of copies
running.

## Clean up
Remove your app but keep the cluster:

```
kubectl delete -f deployment.yaml
kubectl delete -f service.yaml
```

Remove the whole cluster when you are done with this lab:

```
kind delete cluster --name devops-practice
```

Your Docker images stay on your machine, so you can start again
any time with `kind create cluster --name devops-practice`.

## Note on what is unverified here
This lab was not run end-to-end while writing this kit, and kind
version links change over time — if a download link fails, take
the newest link from kind's install page. Mac and Windows steps
are unverified here. If a step fails, read the error message
first, as in every lab in this kit.
