# Start Here — DevOps Kit v1 (Draft)

## Who this is for
A beginner who wants to learn DevOps but does not know where to start.
You need only a computer and internet. No paid course is needed to start.

## The one rule
Learn one step at a time, in this order. Do not jump to Kubernetes
before you can use Linux and Git. At every step, build one small thing.
Reading alone is not enough.

## How to use these files
- **zero-cost-lab.md** — set up your machine and run your first
  container. Do this first.
- **break-and-fix-labs.md** — practise fixing things that break on
  purpose. Do these as you learn each tool.
- **portfolio-projects.md** — the three projects that prove your
  skills. Build them in order.
- **kubernetes-lab.md** — run your Project 1 app on a small local
  cluster. Do this in Step 4.
- **cheat-sheets.md** — keep open while you practise.
- **interview-pack.md** — practise answering out loud, after the
  projects.
- **resume-bullets.md** — turn finished projects into honest
  resume lines.
- **best-sites.md** — only when you are stuck on a topic and want
  another explanation.

## Words you will see a lot
- **DevOps** — a way of working where building software and running
  software are done together, not by two separate teams.
- **Server** — a computer that runs your app for other people to use.
- **Cloud** — renting servers on the internet instead of owning them.
- **Pipeline** — an automatic chain of steps: test the code, build it,
  then put it live.
- **Container** — a small box that holds an app and everything it needs
  to run, so it runs the same on any machine.
- **Terminal** — a window where you type commands instead of clicking.
- **Image** — a saved, ready-to-run copy of an app. A container is
  an image running.
- **Repository (repo)** — a project folder that Git tracks, usually
  stored on GitHub.
- **YAML** — a plain-text way of writing settings with indentation
  (spaces matter). Pipelines, Compose files, and Kubernetes files
  all use it.
- **Script** — a small text file full of commands, which runs them
  one by one for you.
- **DNS** — the internet's address book: it turns a name like
  example.com into a computer's address.
- **HTTP** — the language a browser uses to ask a web server for a
  page.

## The order

### Step 1 — Linux (about 2 weeks, 1–2 hours a day)
Learn: moving around folders, listing files, reading files, file
permissions, running and stopping programs, checking what is using
the machine, and writing one tiny script that runs commands for
you (see zero-cost-lab.md Step 8). Also learn the network basics:
a port (a numbered door), DNS (names to addresses), and HTTP (the
browser asking a server for a page).
Skip for now: deep system setup, kernel details, advanced networking.
You are done when: you can set up a folder, install a tool, and find
why a program stopped, using only the terminal.

### Step 2 — Git (about 1 week)
Learn: save your work, look at past versions, make a branch (a safe
copy to try changes in), merge it back, fix a merge conflict (two
people changed the same lines — see break-and-fix-labs.md Lab 4),
and push to GitHub.
Skip for now: rewriting history, complex merge tricks.
You are done when: your practice work lives on GitHub with a clear
history of changes.

### Step 3 — Docker (about 2–3 weeks)
Learn: what a container is, how to build one from a Dockerfile (a
short recipe file), how to run it, map ports, stop it, and share
a folder into a container with a volume (so files survive after
the container is removed).
Skip for now: Docker Swarm, advanced networking, building your own
base images.
You are done when: you can put a small website in a container and
open it in your browser.

### Step 4 — Kubernetes (about 3–4 weeks)
Learn: pods (the smallest thing Kubernetes runs, usually one
container), deployments (a way to say "keep 2 copies of my app
running"), services (a stable address for your app), and reading logs.
Skip for now: service mesh, operators, running a big production
cluster.
You are done when: you can run your container app on a small local
cluster, expose it with a Service, and fix it when it crashes.
Hands-on lab: kubernetes-lab.md — it walks you through kind, your
Project 1 app, a Service, and fixing a crashed pod.

### Step 5 — Terraform (about 2 weeks)
Learn: writing down what infrastructure you want in a file, and
letting Terraform create it. Terraform is called "infrastructure as
code" — infrastructure means servers, networks, and settings.
Terraform keeps a state file: a record of what it created, so it
knows what to change next time.
Skip for now: remote state servers, workspaces, writing your own
modules.
You are done when: one Terraform file creates your practice setup,
and running it again changes nothing.

### Step 6 — CI/CD (about 2 weeks)
Learn: a pipeline that runs on every code change — check the code,
build it, run a simple test, then deploy it. CI means continuous
integration (merging code often and testing it). CD means continuous
delivery (getting it ready to go live automatically).
Skip for now: multi-environment release rules, canary deployments
(sending a new version to a few users first).
You are done when: pushing code to GitHub starts your pipeline by
itself and you can read its log when it fails.

### Step 7 — Monitoring (about 1–2 weeks)
Learn: Prometheus (collects numbers about your app, like how much
memory it uses) and Grafana (turns those numbers into charts).
Learn what to watch: is the app up, is it slow, is it out of memory?
Skip for now: alerting rules for big teams, log analysis platforms.
You are done when: you have a Grafana chart showing your
monitoring targets are up (see Project 3 in portfolio-projects.md
for the setup).

## Rough total
About 3–4 months at 1–2 hours a day. This is a rough guide, not a
promise. Slow is fine. Finished projects beat finished videos.

## What to skip entirely for now
- Learning every tool at once.
- Paid certificates before you have projects.
- Copying commands you do not understand. If a command fails, read
  the error message first — that is the real skill.

## What this kit will NOT promise
No job guarantee. No salary number. This kit teaches skills and
helps you build proof. Hiring depends on the employer, the market,
and your interview — things no kit can promise.
