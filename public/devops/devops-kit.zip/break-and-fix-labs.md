# Break-and-Fix Labs — Learn Like On-Call Work (Draft)

## How to use these labs
Each lab breaks something on purpose. Do not read the fix first.
Read the symptom, try to find the cause with the commands you know,
then check the fix. In real on-call work (being the person who fixes
things when they break), this order — symptom, logs, cause, fix —
is the whole job.

---

## Lab 1 — The container that will not start

### Break it
```
docker run -d --name broken-web nginxg
```

(`nginxg` is a typing mistake on purpose. There is no such image.)

### Symptom
Docker prints an error and no container runs.

### Find it
```
docker ps -a
```
No `broken-web` container is running. The error message says the
image could not be found — Docker could not download something
that does not exist.

### Fix it
```
docker run -d --name working-web nginx
docker ps
```
The container runs. Lesson: when a container will not start, check
the image name first, then the logs.

### Second version (try this yourself)
```
docker run -d --name second-web -p 8080:80 nginx
```
If your first web container is still using port 8080, this one
fails with "port is already allocated". Fix: stop the first one
(`docker stop my-site`) or use a different port (`-p 8081:80`).

---

## Lab 2 — The container that starts, then dies

### Break it
```
docker run --name dying-app ubuntu badcommand
```

### Symptom
The container appears, then stops at once.

### Find it
```
docker ps -a
docker logs dying-app
```
`docker ps -a` shows it exited. `docker logs` shows the error:
the command does not exist, so the container had nothing to do and
exited. A container lives only as long as its main program runs.

### Fix it
```
docker rm dying-app
docker run -d --name living-app ubuntu sleep 1000
docker ps
```
`sleep 1000` is a program that simply waits, so the container stays
alive. Clean up when done: `docker stop living-app` and
`docker rm living-app`.

---

## Lab 3 — The pipeline that fails

### The setup
Make a folder with a GitHub Actions workflow file (GitHub Actions
is GitHub's built-in pipeline tool). The file lives at
`.github/workflows/check.yml` in a repository:

```yaml
name: check
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run the tests
        run: ./run-tests.sh
```

### Break it
Do not create `run-tests.sh` in the repository. Push the code.

### Symptom
The pipeline runs and fails at the "Run the tests" step.

### Find it
Open the failed run on GitHub and read its log. The log says the
file was not found. The pipeline did exactly what it was told — it
tried to run a file that does not exist.

### Fix it
Either add a real `run-tests.sh` file (even a tiny one that prints
"tests passed"), or change the step to a command that exists, for
example `run: echo "tests passed"`. Push again and watch the
pipeline go green.

### Lesson
Most pipeline failures are not mysterious. Read the failed step's
log, find the first error line, and fix that one thing first.

---

## Lab 4 — The Git merge conflict

### The setup
Make a folder and set up a small history. Git needs to know who
you are before your first commit, so set that once:

```
mkdir -p ~/devops-practice/git-conflict
cd ~/devops-practice/git-conflict
git init
git branch -M main
git config user.name "Learner"
git config user.email "learner@example.com"
```

Now make a first version and save it:

```
cat > notes.txt << 'EOF'
Line one
EOF
git add notes.txt
git commit -m "first version"
```

Make a branch (a safe copy to try changes in) and change the same
line there:

```
git checkout -b feature
cat > notes.txt << 'EOF'
Line one, edited on feature
EOF
git add notes.txt
git commit -m "feature edit"
```

Go back to the main line and change the same line differently:

```
git checkout main
cat > notes.txt << 'EOF'
Line one, edited on main
EOF
git add notes.txt
git commit -m "main edit"
```

### Break it
Try to merge the branch in:

```
git merge feature
```

### Symptom
Git stops and says there is a CONFLICT in `notes.txt`. Nothing is
merged yet. This is normal — Git is asking you to choose, not
telling you something broke badly.

### Find it
```
cat notes.txt
```

You will see markers like this:

```
<<<<<<< HEAD
Line one, edited on main
=======
Line one, edited on feature
>>>>>>> feature
```

The top half (between `<<<<<<<` and `=======`) is your current
branch's version. The bottom half (between `=======` and
`>>>>>>>`) is the incoming branch's version.

### Fix it
Edit `notes.txt` so it holds the one version you want, and delete
all three marker lines. For example, keep:

```
Line one, edited on main
```

Then finish the merge:

```
git add notes.txt
git commit
```

The merge is done. Lesson: a conflict is Git showing you both
versions side by side. Read the markers, pick the right lines,
remove the markers, and commit. Never commit a file with marker
lines still in it.

---

## Lab 5 — The app runs, but the browser shows nothing

### Break it
```
docker run -d --name quiet-web nginx
```

No port mapping this time — that is the mistake, on purpose.

### Symptom
`docker ps` shows `quiet-web` running. But opening
`http://localhost:8080` in your browser says the site cannot be
reached. The app is fine. The door to it is missing.

### Find it
```
docker ps
docker logs quiet-web
```

`docker ps` shows no port mapping under PORTS for this
container. `docker logs` shows nginx started normally. So the
container works — your machine simply has no door into it.
A container's own port 80 does not reach your browser by itself;
the `-p` mapping is what connects the two.

### Fix it
```
docker stop quiet-web
docker rm quiet-web
docker run -d -p 8080:80 --name quiet-web nginx
```

Open `http://localhost:8080` again — the welcome page appears.

### Second version (try this yourself)
Stop the first container, then run one with a different host port:

```
docker stop quiet-web
docker run -d -p 8081:80 --name second-quiet nginx
```

Opening `http://localhost:8080` now shows nothing — nothing
answers there any more. Open `http://localhost:8081` and it
works. Lesson: the first number in `-p` is your machine's door;
the second is the container's. Check which door you actually
opened.

---

## Lab 6 — The build fails: file not found

### The setup
Make a folder with a Dockerfile that copies a file which does
not exist there:

```
mkdir -p ~/devops-practice/build-fail
cd ~/devops-practice/build-fail
cat > index.html << 'EOF'
<h1>My site</h1>
EOF
cat > Dockerfile << 'EOF'
FROM nginx
COPY app.html /usr/share/nginx/html/app.html
EOF
```

### Break it
```
docker build -t fail-demo:1.0 .
```

### Symptom
The build stops at the COPY step with an error like "file not
found". The folder holds `index.html`, but the Dockerfile asks
for `app.html`, which is not there.

### Find it
Read the failed step in the build output: it names the missing
file. Then check what is actually in the folder:

```
ls
```

The build can only see files in the folder you build from. The
dot in `docker build -t fail-demo:1.0 .` means "this folder" —
that folder is called the build context, and files outside it
are invisible to the build.

### Fix it
Either create the missing file, or fix the Dockerfile to copy
the file that exists. The honest fix here is the second one:

```
cat > Dockerfile << 'EOF'
FROM nginx
COPY index.html /usr/share/nginx/html/index.html
EOF
docker build -t fail-demo:1.0 .
```

The build passes. Lesson: when a build says a file is not
found, check two things — does the file exist, and is it inside
the folder you are building from?

---

## After all six labs
You can now say, truthfully: "I can read container logs, fix a port
clash, fix a bad image name, resolve a merge conflict, find a
missing port mapping, fix a failed build, and read a failed
pipeline log."
That sentence is worth more than a certificate with no practice.
