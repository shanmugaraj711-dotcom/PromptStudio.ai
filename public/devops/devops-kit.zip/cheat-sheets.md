# Cheat Sheets — Commands You Will Actually Use (Draft)

Keep this file open while you practise. All commands below are
standard, well-known commands for their tools.

## Making files
```
nano <file>            Open a file in a simple text editor
                       (Ctrl+O, Enter to save, Ctrl+X to leave)
cat > <file> << 'EOF'  Write lines into a file until the EOF line
```
YAML warning: use spaces, never Tab, in `.yml` files.

## Linux
```
pwd                    Show which folder you are in
ls -la                 List files, including hidden ones
cd <folder>            Move into a folder
mkdir <name>           Make a new folder
cat <file>             Print a file's contents
grep <word> <file>     Find a word inside a file
chmod +x <file>        Make a file runnable
ps aux                 List running programs
top                    Watch live CPU and memory use
df -h                  Show disk space
free -h                Show memory use
sudo systemctl start <service>    Start a service
sudo systemctl status <service>   Check a service
```

## Git
```
git init               Start tracking a folder
git clone <address>    Copy a repository from GitHub to your machine
git config user.name "Your Name"    Tell Git who you are (once)
git config user.email "you@example.com"   (once)
git status             Show what changed
git add .              Stage all changes
git commit -m "message"   Save changes with a message
git log --oneline      Show past saves, one line each
git branch             List branches
git checkout -b <name>   Make a new branch and move into it
git merge <branch>     Merge a branch into the current one
git push               Send your saves to GitHub
git pull               Download and merge the latest changes
```

## Docker
```
docker ps              List running containers
docker ps -a           List all containers, including stopped ones
docker images          List downloaded images
docker run hello-world   Prove Docker works
docker run -d -p 8080:80 --name web nginx
                       Run nginx in the background on port 8080
docker logs <name>     Read a container's output
docker stop <name>     Stop a container
docker start <name>    Start a stopped container
docker rm <name>       Remove a stopped container
docker build -t <name>:<tag> .   Build an image from a Dockerfile
docker exec -it <name> sh   Open a shell inside a running container
docker run -d -v ~/data:/data --name store ubuntu sleep 1000
                       Share folder ~/data into the container
docker compose up -d   Start the containers in docker-compose.yml
docker compose ps      List containers started by Compose
docker compose down    Stop and remove Compose containers
```

## Kubernetes (kubectl)
`kubectl` is the command tool for talking to a Kubernetes cluster.
```
kubectl get pods       List pods
kubectl get nodes      List cluster machines
kubectl get deployments   List deployments
kubectl get services   List services
kubectl port-forward service/<name> 8080:80
                       Open a service in your browser
kubectl describe pod <name>   Show details about one pod
kubectl logs <pod>     Read a pod's logs
kubectl apply -f <file.yaml>   Create things from a file
kubectl delete -f <file.yaml>  Remove things from a file

## kind (local Kubernetes)
```
kind create cluster --name devops-practice   Start a local cluster
kind load docker-image my-site:1.0 --name devops-practice
                       Copy a local image into the cluster
kind delete cluster --name devops-practice   Remove the cluster
```
```

## Terraform
```
terraform init         Prepare a folder for Terraform
terraform plan         Show what Terraform would change
terraform apply        Create or change the infrastructure
terraform destroy      Remove everything Terraform created
```
Warning: `terraform destroy` deletes things. Only run it on your
own practice setup, never on anything shared or real.

## Prometheus and Grafana (concepts, not commands)
- Prometheus collects numbers (metrics) from your apps.
- Grafana turns those numbers into charts.
- The two things to check first: is the app up, and is it slow?
