# Portfolio Projects — Proof, Not Just Notes (Draft)

## Why projects
Employers trust things they can open and run. Three small, finished
projects beat a long list of courses. Each project below ends with a
GitHub README (the front page of a repository) that you fill in.
Write only true things in it. If something is not done yet, say so.

---

## Project 1 — A website in a container

### Build it
1. Make a folder called `my-site` inside `~/devops-practice` and
   put one `index.html` page in it that says what the site is.
   Then move into that folder before you build:

```
cd ~/devops-practice/my-site
```

   Example content for `index.html` (make it with the method in
   zero-cost-lab.md, "How to make a file"):

```html
<h1>My DevOps practice site</h1>
<p>This site runs in a Docker container I built myself.</p>
```
2. Add a `Dockerfile` — the recipe file that tells Docker how to
   build your container:

```dockerfile
FROM nginx
COPY index.html /usr/share/nginx/html/index.html
```

3. From inside the `my-site` folder, build and run it:
```
docker build -t my-site:1.0 .
docker run -d -p 8080:80 my-site:1.0
```
4. Open `http://localhost:8080` and check it works.
5. Push the folder to GitHub (first time: follow zero-cost-lab.md
   Step 7; after that, `git add .`, `git commit`, `git push`).

### README template — fill in the blanks
```
# [Site name]
What it is: [one line]
Tools used: Docker, nginx, HTML
How to run it:
  docker build -t my-site:1.0 .
  docker run -d -p 8080:80 my-site:1.0
  Open http://localhost:8080
What I learned: [two lines]
Problems I fixed: [one problem and its fix]
```

---

## Project 2 — A pipeline that tests and builds

### Build it
1. Use Project 1's repository.
2. Make the folder for the workflow file, then add
   `.github/workflows/build.yml` (see zero-cost-lab.md, "How to
   make a file", for how to create files):

```
mkdir -p .github/workflows
```

```yaml
name: build
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build the image
        run: docker build -t my-site:1.0 .
```

3. Push, open the Actions tab on GitHub, and watch the pipeline
   run. Break it once on purpose (for example, a typo in the
   Dockerfile), read the log, fix it, and push again.

### README template — fill in the blanks
```
# [Site name] — CI/CD pipeline
What it is: [one line]
Pipeline does: on every push, it builds the Docker image.
Tools used: GitHub Actions, Docker
A failure I fixed: [what broke, what the log said, what I changed]
Pipeline status: [link to the Actions tab, if public]
```

---

## Project 3 — Infrastructure as code + monitoring, zero-cost

### Build it
1. Install Terraform (the tool that creates infrastructure from
   files). Its install steps differ by system, so follow the
   official Terraform install docs for your machine — this step is
   unverified in this kit.
2. Write a small Terraform file called `main.tf` (Terraform reads
   every `.tf` file in the folder) that creates a local container
   using the Docker provider (Terraform talks to Docker on your own
   machine — no cloud account, no bill):

```hcl
terraform {
  required_providers {
    docker = {
      source = "kreuzwerker/docker"
    }
  }
}

resource "docker_image" "web" {
  name = "nginx:latest"
}

resource "docker_container" "web" {
  image = docker_image.web.image_id
  name  = "terraform-web"
  ports {
    internal = 80
    external = 8080
  }
}
```

Run `terraform init`, then `terraform apply`, and check
`http://localhost:8080`. `init` downloads the Docker provider the
file asks for. Run `terraform apply` again — it should
report nothing to change.
Clean up when you are done: `terraform destroy` removes what
Terraform created. Only run it on your own practice setup, never
on anything shared or real.
3. Add monitoring with Docker Compose (a tool that starts several
   containers together from one file). You will run three small
   programs on your own machine: Prometheus (collects numbers),
   Grafana (turns numbers into charts), and node-exporter (reports
   numbers about the machine your containers run on). No cloud
   account, no bill.

   Make a folder called `monitoring` inside `~/devops-practice`
   and put two files in it.

   File 1 — `docker-compose.yml`:

```yaml
services:
  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
  node-exporter:
    image: prom/node-exporter
    ports:
      - "9100:9100"
  grafana:
    image: grafana/grafana
    ports:
      - "3000:3000"
```

   File 2 — `prometheus.yml` (the file that tells Prometheus
   what to watch — a "scrape" is Prometheus visiting an address
   every 15 seconds and writing down numbers):

```yaml
global:
  scrape_interval: 15s
scrape_configs:
  - job_name: "prometheus"
    static_configs:
      - targets: ["localhost:9090"]
  - job_name: "practice-machine"
    static_configs:
      - targets: ["node-exporter:9100"]
```

   A "job" is just a named thing to watch. `node-exporter:9100`
   works because Docker Compose lets containers reach each other
   by service name. `localhost:9090` works for Prometheus itself
   because it is watching its own container.

   Start it all:

```
cd ~/devops-practice/monitoring
docker compose up -d
docker compose ps
```

   All three should show as running. If `docker compose` fails,
   older Docker uses `docker-compose` (with a hyphen) — try that
   instead.

   Check Prometheus first: open `http://localhost:9090`, click
   Status, then Targets. Both jobs should show UP. If a target
   shows DOWN, read the error line under it first.

   Now open Grafana: `http://localhost:3000`. Log in with
   username `admin` and password `admin`. If it asks you to set
   a new password, set one you will remember.

   Add Prometheus as the data source: go to Connections, then
   Data sources, then Add data source, choose Prometheus, and set
   the URL to `http://prometheus:9090` — Grafana reaches
   Prometheus by its service name, not by localhost. Then Save &
   test. It should say the data source is working.

   Make your first chart: create a new Dashboard, add a
   Visualization, choose Prometheus, type the query `up`, and run
   it. The chart shows 1 for every target that is up and 0 for
   one that is down. Save the dashboard and keep a screenshot
   of it.

   Stop everything when you are done: `docker compose down`.
   Your files stay, so `docker compose up -d` starts it again
   later.

   Note: Grafana's menu words can differ slightly by version —
   if a button name differs, look for the closest match. This
   exact stack was not run end-to-end while writing this kit,
   so if a step fails, read the error message first.
4. Push everything to GitHub.

### A clear warning
Terraform with a cloud provider (AWS, Azure, and similar) can cost
real money. Do the local Docker version first. Only try a cloud
version if you understand that provider's free tier and you destroy
what you create afterwards. This kit does not promise any setup is
free on the cloud.

### README template — fill in the blanks
```
# Terraform + monitoring demo
What it is: [one line]
Tools used: Terraform, Docker, Prometheus, Grafana
How to run it: [the commands you used]
What the chart shows: [one line — for example, "both monitoring targets are up: Prometheus and the practice machine"]
What I learned: [two lines]
Cost: local only, no cloud bill.
```

---

## When all three are done
You have: a running container app, a working pipeline, and an
infrastructure-as-code setup with a monitoring chart — all on
GitHub, all runnable, all explained in your own words. That is the
proof this kit is built to give you.
