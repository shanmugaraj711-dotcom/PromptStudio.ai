# Resume Bullets — From Your Projects, In Simple Words (Draft)

## Rules before you copy anything
- Write only what you actually did. Fill in the blanks with your
  real project details.
- Never invent numbers, company names, or job titles.
- One bullet = one fact + one result. Keep each bullet to one line.
- If a bullet is not true for you yet, leave it out until it is.

## From Project 1 — Website in a container
- Built and ran a containerised website using Docker and nginx,
  reachable at a mapped port on a local machine.
- Wrote a Dockerfile that builds the website image from a simple
  web page.
- [Your detail:] Deployed the site image version [version] and
  verified it in a browser.

## From Project 2 — CI/CD pipeline
- Set up a GitHub Actions pipeline that tests the site, then builds a Docker image on
  every push to the repository.
- Read a failed pipeline log, found the [error you fixed], and
  fixed it so the pipeline passed.
- Kept the project's build history visible in the repository's
  Actions tab.

## From Project 3 — Terraform + monitoring
- Wrote Terraform files that create a local container setup, and checked with `terraform plan` that a second run needed no changes.
- Added Prometheus and Grafana to watch the practice setup, with a
  chart showing [what your chart shows].
- Ran the whole practice setup locally with no cloud bill.

## From the break-and-fix labs
- Diagnosed a container that would not start by reading its error
  message and correcting the image name.
- Fixed a port clash by finding the running container and changing
  the port mapping.
- Debugged a container that exited at once by reading its logs and
  finding the bad command.
- Resolved a Git merge conflict by reading the conflict markers
  and keeping the correct lines.
- Wrote a small Bash health-check script and made it runnable with
  chmod.
- Found a missing port mapping when a running container did not
  answer in the browser.

## A short summary you can adapt
"Beginner DevOps learner. Built a containerised website, a CI/CD
pipeline, and a Terraform + monitoring demo, all on GitHub. Can
read logs, fix failed builds, and explain my own projects."

## What NOT to write
- Do not write "expert" or "experienced DevOps engineer" unless a
  real job gave you that role.
- Do not list tools you only watched videos about. List tools you
  actually ran.
- Do not copy someone else's project description. Yours is smaller
  and true — that is better.
